import React, { useState, useEffect } from 'react';
import Logo from '../../Images/logo.png';
import LogoutIcon from '@mui/icons-material/Logout';
import {
  AppBar,
  Toolbar,
  Box,
  Typography,
  IconButton,
  Button,
  Avatar,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Menu,
  MenuItem,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import { ExpandLess, ExpandMore } from '@mui/icons-material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { baseurl } from '../../BaseURL/BaseURL';
import { Badge, Menu as MuiMenu } from '@mui/material';
import axios from 'axios';

export default function PartnerHeader() {
  // Define nav items with navigation paths.
  // For the "Transactions" item, we add a submenu.

  const userId = localStorage.getItem("user_id");
  const [notifications, setNotifications] = useState([]);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const notificationMenuOpen = Boolean(notificationAnchorEl);

  const handleNotificationClick = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };
  const handleNotificationClose = () => {
    setNotificationAnchorEl(null);
  };

    useEffect(() => {
    const fetchNotifications = () => {
      axios.get(`${baseurl}/notifications/user-id/${userId}/`)
        .then(response => {
          const unread = response.data.filter(n => !n.is_read);
          setNotifications(unread);
        })
        .catch(error => {
          console.error("Error fetching notifications:", error);
        });
    };

    fetchNotifications(); // Initial load
    const interval = setInterval(fetchNotifications, 10000); // Every 10s
    return () => clearInterval(interval);
  }, [userId]);


  const navItems = [
    { label: 'Dashboard', path: '/p-dashboard' },
    { label: 'My Properties', path: '/p-myassets' },
    { label: 'Properties', path: '/p-assets' },
    // { label: 'Transaction', path: '/p-transaction' },
    // {
    //   label: 'Transactions', path:"/p-transactions",
    //   path: '/p-transactions',
    //   submenu: [
    //     { label: 'Buy Shares', path: '/buy-shares' },
    //     { label: 'Sell Shares', path: '/sell-shares' },
    //   ],
    // },
    { label: 'My Team', path: '/p-myteam' },
    // { label: 'Report', path: '/p-report' },
    // { label: 'Commission', path: '/p-commission' },
    // { label: 'Plans', path: '/p-plans' },
    {
      label: 'Operations',
      subItems: [
        { label: 'Transaction', path: '/p-transaction' },
        { label: 'Commission', path: '/p-commission' },
        { label: 'Plans', path: '/p-plans' },
        { label: 'Training Material', path: '/p-trainingmaterial' },
      ]
    },
    { label: 'Meetings', path: '/p-meetings' },
  ];


  // Responsive helper.
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const referral_id = localStorage.getItem("referral_id");
  const first_name = localStorage.getItem("user_name");

  // Navigation hooks.
  const navigate = useNavigate();
  const location = useLocation();

  // State for mobile drawer.
  const [mobileOpen, setMobileOpen] = useState(false);
  // State for Operations dropdown menu
  const [operationsAnchorEl, setOperationsAnchorEl] = useState(null);
  const operationsMenuOpen = Boolean(operationsAnchorEl);
  const handleOperationsClick = (event) => {
    setOperationsAnchorEl(event.currentTarget);
  };
  const handleOperationsMenuClose = () => {
    setOperationsAnchorEl(null);
  };

  // Check if any sub-item is active for highlighting the Operations button
  const isOperationsActive = navItems
    .find(item => item.label === 'Operations')
    ?.subItems.some(subItem => location.pathname === subItem.path);
  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };

  // State for the Profile Avatar dropdown menu.
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const profileMenuOpen = Boolean(profileAnchorEl);
  const handleAvatarClick = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };
  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };

  // State for the Transactions dropdown menu in desktop view.
  const [transAnchorEl, setTransAnchorEl] = useState(null);
  const transMenuOpen = Boolean(transAnchorEl);
  const handleTransClick = (event) => {
    setTransAnchorEl(event.currentTarget);
  };
  const handleTransClose = () => {
    setTransAnchorEl(null);
  };

  // Drawer content for mobile view with a close (cross) button.
  const drawer = (
    <Box sx={{ width: 250 }}>
      {/* Drawer header with a close icon */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
        <IconButton onClick={handleDrawerToggle}>
          <CloseIcon />
        </IconButton>
      </Box>

      <List>
        {navItems.map((item) => (
          <ListItem key={item.label} disablePadding>
            <ListItemButton
              onClick={() => {
                handleDrawerToggle();
                navigate(item.path);
              }}
            >
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{
                  color: location.pathname === item.path ? 'blue' : 'inherit',
                  fontWeight: 'bold',
                }}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <>
      <AppBar
        position="fixed"
        sx={{
          backgroundColor: 'white',
          color: '#000',
          boxShadow: "-moz-initial"
        }}
      >
        <Toolbar>
          {isMobile ? (
            // Mobile / iPad Layout.
            <Box display="flex" alignItems="center" justifyContent="space-between" width="100%">
              {/* Left: Menu Icon */}
              <IconButton
                edge="start"
                color="inherit"
                aria-label="menu"
                onClick={handleDrawerToggle}
                sx={{ mr: 2 }}
              >
                <MenuIcon />
              </IconButton>

              {/* Center: Logo */}
              <Box display="flex" justifyContent="center" flexGrow={1}>
                <Link to="/p-dashboard" style={{ textDecoration: 'none', color: '#333333' }}>
                  <img
                    src={Logo}
                    alt="logo"
                    style={{
                      height: '50px',
                      width: 'auto',
                      maxWidth: '150px',
                      // transform: 'scale(2.0)',
                    }}
                  />
                </Link>
              </Box>

              {/* Right: Notification, Username, Profile Avatar */}
              <Box display="flex" alignItems="center">
                <IconButton sx={{ color: '#000' }} onClick={handleNotificationClick}>
                <Badge badgeContent={notifications.length} color="error">
                  <NotificationsNoneIcon />
                </Badge>
              </IconButton>
                <Typography sx={{ ml: 2, mr: 2, color: '#000', fontWeight: 'bold' }}>
                  {first_name} ({referral_id})
                </Typography>
                <Avatar
                  onClick={handleAvatarClick}
                  sx={{ width: 40, height: 40, cursor: 'pointer' }}
                  alt="Profile Avatar"
                  src="https://via.placeholder.com/40" // Replace with your own image.
                />
              </Box>
            </Box>
          ) : (
            // Desktop Layout.
            <>
              {/* Left: Logo */}
              <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center' }}>
                <Link to="/p-dashboard" style={{ textDecoration: 'none', color: '#333333' }}>
                  <img
                    src={Logo}
                    alt="logo"
                    style={{
                      height: '75px',
                      width: 'auto',
                      maxWidth: '150px',
                      paddingTop: "8px"
                      // transform: 'scale(2.0)',
                    }}
                  />
                </Link>
              </Typography>

              {/* Center: Nav Items */}
              <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'center', gap: 3 }}>
                {navItems.map((item) => (
                  item.path ? (
                    <Button
                      key={item.label}
                      onClick={() => navigate(item.path)}
                      sx={{
                        color: location.pathname === item.path ? 'blue' : '#000',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        fontSize: "16px"
                      }}
                    >
                      {item.label}
                    </Button>
                  ) : (
                    <Button
                      key={item.label}
                      onClick={handleOperationsClick}
                      endIcon={<ArrowDropDownIcon />}
                      sx={{
                        color: isOperationsActive ? 'blue' : '#000',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        fontSize: "16px"
                      }}
                    >
                      {item.label}
                    </Button>
                  )
                ))}
              </Box>
              {/* Right: Notification, Username, Profile Avatar */}
              <IconButton sx={{ color: '#000' }} onClick={handleNotificationClick}>
                <Badge badgeContent={notifications.length} color="error">
                  <NotificationsNoneIcon />
                </Badge>
              </IconButton>

              <Typography sx={{ ml: 2, mr: 2, color: '#000', fontWeight: 'bold' }}>
                {first_name} ({referral_id})
              </Typography>
              <Avatar
                onClick={handleAvatarClick}
                sx={{ width: 40, height: 40, cursor: 'pointer' }}
                alt="Partner"
                src="https://via.placeholder.com/40" // Replace with your own image.
              />
            </>
          )}
        </Toolbar>

        {/* Mobile Drawer */}
        <Drawer
          anchor="left"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
        >
          {drawer}
        </Drawer>
      </AppBar>

      {/* Operations Dropdown Menu */}
      <Menu
        anchorEl={operationsAnchorEl}
        open={operationsMenuOpen}
        onClose={handleOperationsMenuClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        transformOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        {navItems.find(item => item.label === 'Operations')?.subItems.map((subItem) => (
          <MenuItem
            key={subItem.label}
            onClick={() => {
              handleOperationsMenuClose();
              navigate(subItem.path);
            }}
            sx={{
              fontWeight: 'bold',
              color: location.pathname === subItem.path ? 'blue' : 'inherit',
              fontSize: "16px"
            }}
          >
            {subItem.label}
          </MenuItem>
        ))}
      </Menu>
      {/* Profile Avatar Dropdown Menu */}
      <Menu
        anchorEl={profileAnchorEl}
        open={profileMenuOpen}
        onClose={handleProfileMenuClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MenuItem
          onClick={() => {
            handleProfileMenuClose();
            navigate('/p-profile');
          }}
          sx={{ fontWeight: 'bold' }}
        >
          Profile
        </MenuItem>
        {/* <MenuItem
          onClick={() => {
            handleProfileMenuClose();
            navigate('/p-profiledetails');
          }}
          sx={{ fontWeight: 'bold' }}
        >
          KYC
        </MenuItem> */}
        <MenuItem
          onClick={() => {
            handleProfileMenuClose();
            navigate('/login');
          }}
          sx={{
            fontSize: '16px',
            fontWeight: 'bold',
            color: "red",
            display: 'flex',
            alignItems: 'center'
          }}
        >
          Logout <LogoutIcon sx={{ ml: 1 }} />
        </MenuItem>
      </Menu>

      <MuiMenu
        anchorEl={notificationAnchorEl}
        open={notificationMenuOpen}
        onClose={handleNotificationClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        {notifications.length > 0 ? (
          notifications.map((notif) => (
            <MenuItem
              key={notif.notification_status_id}
              onClick={() => {
                axios.post(`${baseurl}/notifications/mark-as-read/`, {
                  user_id: parseInt(userId),
                  notification_id: notif.notification_status_id
                })
                  .then(() => {
                    setNotifications(prev => prev.filter(n => n.notification_status_id !== notif.notification_status_id));
                    handleNotificationClose();
                    navigate('/p-assets'); 
                  })
                  .catch(error => {
                    console.error("Error marking notification as read:", error);
                  });
              }}
            >
              {notif.message}
            </MenuItem>
          ))
        ) : (
          <MenuItem disabled>No notifications</MenuItem>
        )}
      </MuiMenu>



      {/* Transactions Dropdown Menu for Desktop */}
      {/* <Menu
        anchorEl={transAnchorEl}
        open={transMenuOpen}
        onClose={handleTransClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        transformOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        {navItems
          .find((item) => item.label === 'Transactions')
          .submenu.map((subitem) => (
            <MenuItem
              key={subitem.label}
              onClick={() => {
                handleTransClose();
                navigate(subitem.path);
              }}
              sx={{
                color: location.pathname === subitem.path ? 'blue' : 'inherit',
                fontWeight: 'bold',
                fontSize:"16px"
              }}
            >
              {subitem.label}
            </MenuItem>
          ))}
      </Menu> */}
    </>
  );
}
