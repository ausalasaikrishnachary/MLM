import React, { useState, useEffect } from 'react';
import Logo from '../../Images/logo1.png';
import LogoutIcon from '@mui/icons-material/Logout';
import {
  AppBar,
  Toolbar,
  Box,
  Typography,
  IconButton,
  Button,
  Avatar,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Menu,
  MenuItem,
  useTheme,
  useMediaQuery,
  Badge,
  Menu as MuiMenu
} from '@mui/material';
import { ExpandLess, ExpandMore } from '@mui/icons-material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import axios from 'axios';
import { baseurl } from '../../BaseURL/BaseURL';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

export default function PartnerHeader() {
  const userId = localStorage.getItem("user_id");
  const [notifications, setNotifications] = useState([]);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const notificationMenuOpen = Boolean(notificationAnchorEl);

  const handleNotificationClick = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };
  const handleNotificationClose = () => {
    setNotificationAnchorEl(null);
  };

  const [profileImage, setProfileImage] = useState('');

 useEffect(() => {
  const fetchProfileImageAndBirthday = () => {
    axios.get(`${baseurl}/users/${userId}/`)
      .then(res => {
        const user = res.data;
        setProfileImage(user.image || '');

        // 🎂 Birthday check
        if (user.date_of_birth) {
          const today = new Date();
          const dob = new Date(user.date_of_birth);

          if (
            dob.getDate() === today.getDate() &&
            dob.getMonth() === today.getMonth()
          ) {
            // Add birthday wish as a notification (local)
            setNotifications(prev => [
              ...prev,
              {
                notification_status_id: "birthday_" + userId,
                message: `🎉 Happy Birthday, ${user.first_name || "User"}! 🎂`,
                is_read: false,
              }
            ]);
          }
        }
      })
      .catch(err => {
        console.error('Error fetching profile image:', err);
      });
  };

  const fetchNotifications = () => {
    axios.get(`${baseurl}/notifications/user-id/${userId}/`)
      .then(response => {
        const unread = response.data.filter(n => !n.is_read);
        setNotifications(prev => {
          // avoid duplicates when merging birthday + API notifications
          const all = [...unread, ...prev];
          const unique = [];
          const seen = new Set();
          for (let n of all) {
            if (!seen.has(n.notification_status_id)) {
              unique.push(n);
              seen.add(n.notification_status_id);
            }
          }
          return unique;
        });
      })
      .catch(error => {
        console.error("Error fetching notifications:", error);
      });
  };

  fetchProfileImageAndBirthday();
  fetchNotifications();
  const interval = setInterval(fetchNotifications, 10000);
  return () => clearInterval(interval);
}, [userId]);


  const navItems = [
    { label: 'Dashboard', path: '/p-dashboard' },
    { label: 'My Properties', path: '/p-myassets' },
    { label: 'Properties', path: '/p-assets' },
    { label: 'Add Property', path: '/p-addasset' },
    { label: 'My Team', path: '/p-myteam' },
    {
      label: 'Operations',
      subItems: [
        { label: 'Transaction', path: '/p-transaction' },
        { label: 'Commission', path: '/p-commission' },
        { label: 'Plans', path: '/p-plans' },
        { label: 'Training Material', path: '/p-trainingmaterial' },
        { label: 'Add Business', path: '/p-viewbusiness' },
      ]
    },
    { label: 'Meetings', path: '/p-meetings' },
  ];

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const referral_id = localStorage.getItem("referral_id");
  const first_name = localStorage.getItem("user_name");

  const navigate = useNavigate();
  const location = useLocation();
   const goBack = () => navigate(-1);

  const [mobileOpen, setMobileOpen] = useState(false);
  const [operationsAnchorEl, setOperationsAnchorEl] = useState(null);
  const operationsMenuOpen = Boolean(operationsAnchorEl);
  const handleOperationsClick = (event) => {
    setOperationsAnchorEl(event.currentTarget);
  };
  const handleOperationsMenuClose = () => {
    setOperationsAnchorEl(null);
  };

  const isOperationsActive = navItems
    .find(item => item.label === 'Operations')
    ?.subItems.some(subItem => location.pathname === subItem.path);

  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };

  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const profileMenuOpen = Boolean(profileAnchorEl);
  const handleAvatarClick = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };
  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };

 const [openOperationsMobile, setOpenOperationsMobile] = useState(false);

const drawer = (
  <Box sx={{ width: 250 }}>
    <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
      <IconButton onClick={handleDrawerToggle}>
        <CloseIcon />
      </IconButton>
    </Box>
    <List>
      {navItems.map((item) => (
        item.subItems ? (
          <React.Fragment key={item.label}>
            <ListItemButton onClick={() => setOpenOperationsMobile(!openOperationsMobile)}>
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{
                  fontWeight: 'bold',
                  color: isOperationsActive ? 'blue' : 'inherit',
                }}
              />
              {openOperationsMobile ? <ExpandLess /> : <ExpandMore />}
            </ListItemButton>
            {openOperationsMobile && (
              <Box sx={{ pl: 4 }}>
                {item.subItems.map((subItem) => (
                  <ListItemButton
                    key={subItem.label}
                    onClick={() => {
                      navigate(subItem.path);
                      handleDrawerToggle();
                    }}
                    sx={{
                      backgroundColor: location.pathname === subItem.path ? '#f0f0f0' : 'transparent',
                      borderRadius: '8px',
                    }}
                  >
                    <ListItemText
                      primary={subItem.label}
                      primaryTypographyProps={{
                        fontWeight: 'Bold',
                        color: location.pathname === subItem.path ? 'blue' : 'inherit',
                      }}
                    />
                  </ListItemButton>
                ))}
              </Box>
            )}
          </React.Fragment>
        ) : (
          <ListItem key={item.label} disablePadding>
            <ListItemButton
              onClick={() => {
                navigate(item.path);
                handleDrawerToggle();
              }}
            >
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{
                  fontWeight: 'bold',
                  color: location.pathname === item.path ? 'blue' : 'inherit',
                }}
              />
            </ListItemButton>
          </ListItem>
        )
      ))}
    </List>
  </Box>
);

  return (
    <>
      <AppBar
        position="fixed"
        sx={{
          backgroundColor: 'white',
          color: '#000',
          boxShadow: "-moz-initial"
        }}
      >
        <Toolbar>
          {isMobile ? (
            <Box display="flex" alignItems="center" justifyContent="space-between" width="100%">
              <IconButton
                edge="start"
                color="inherit"
                aria-label="menu"
                onClick={handleDrawerToggle}
                sx={{ mr: 2 }}
              >
                <MenuIcon />
              </IconButton>
              <Box display="flex" justifyContent="center" flexGrow={1}>
                <Link to="/p-dashboard" style={{ textDecoration: 'none', color: '#333333' }}>
                  <img src={Logo} alt="logo" style={{ height: '50px', maxWidth: '150px',transform: 'scale(2.0)', }} />
                </Link>
              </Box>
              <Box display="flex" alignItems="center">
                <IconButton sx={{ color: '#000' }} onClick={handleNotificationClick}>
                  <Badge badgeContent={notifications.length} color="error">
                    <NotificationsNoneIcon />
                  </Badge>
                </IconButton>
                <Typography sx={{ ml: 2, mr: 2, color: '#000', fontWeight: 'bold' }}>
                  {first_name} ({referral_id})
                </Typography>
                <Avatar
                  onClick={handleAvatarClick}
                  sx={{ width: 40, height: 40, cursor: 'pointer' }}
                  alt="Profile Avatar"
                  src={profileImage ? `${baseurl}${profileImage}` : "https://via.placeholder.com/40"}
                />
              </Box>

            </Box>
          ) : (
            <>
              <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center' }}>
                <Link to="/p-dashboard" style={{ textDecoration: 'none', color: '#333333' }}>
                  <img src={Logo} alt="logo" style={{ height: '75px', maxWidth: '150px', transform: 'scale(1.5)', }} />
                </Link>
              </Typography>

               <IconButton
    onClick={goBack}
    sx={{
      backgroundColor: '#f0f0f0',
      color: '#000',
      borderRadius: '12px',
      padding: '8px',
      marginLeft: '20px', // left padding from edge of screen
      marginRight: '10px', // space between button and logo
      transition: 'all 0.3s ease',
      '&:hover': {
        backgroundColor: '#e0e0e0',
        boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
      },
    }}
  >
    <ArrowBackIcon />
  </IconButton>

              <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'center', gap: 3 }}>
                {navItems.map((item) => (
                  item.path ? (
                    <Button
                      key={item.label}
                      onClick={() => navigate(item.path)}
                      sx={{
                        color: location.pathname === item.path ? 'blue' : '#000',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        fontSize: "16px"
                      }}
                    >
                      {item.label}
                    </Button>
                  ) : (
                    <Button
                      key={item.label}
                      onClick={handleOperationsClick}
                      endIcon={<ArrowDropDownIcon />}
                      sx={{
                        color: isOperationsActive ? 'blue' : '#000',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        fontSize: "16px"
                      }}
                    >
                      {item.label}
                    </Button>
                  )
                ))}
              </Box>
              <IconButton sx={{ color: '#000' }} onClick={handleNotificationClick}>
                <Badge badgeContent={notifications.length} color="error">
                  <NotificationsNoneIcon />
                </Badge>
              </IconButton>
              <Typography sx={{ ml: 2, mr: 2, color: '#000', fontWeight: 'bold' }}>
                {first_name} ({referral_id})
              </Typography>
              <Avatar
                  onClick={handleAvatarClick}
                  sx={{ width: 40, height: 40, cursor: 'pointer' }}
                  alt="Profile Avatar"
                  src={profileImage ? `${baseurl}${profileImage}` : "https://via.placeholder.com/40"}
                />
            </>
          )}
        </Toolbar>
        <Drawer
          anchor="left"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
        >
          {drawer}
        </Drawer>
      </AppBar>

      <Menu
        anchorEl={operationsAnchorEl}
        open={operationsMenuOpen}
        onClose={handleOperationsMenuClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        transformOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        {navItems.find(item => item.label === 'Operations')?.subItems.map((subItem) => (
          <MenuItem
            key={subItem.label}
            onClick={() => {
              handleOperationsMenuClose();
              navigate(subItem.path);
            }}
            sx={{
              fontWeight: 'bold',
              color: location.pathname === subItem.path ? 'blue' : 'inherit',
              fontSize: "16px"
            }}
          >
            {subItem.label}
          </MenuItem>
        ))}
      </Menu>

      <Menu
        anchorEl={profileAnchorEl}
        open={profileMenuOpen}
        onClose={handleProfileMenuClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MenuItem
          onClick={() => {
            handleProfileMenuClose();
            navigate('/p-profile');
          }}
          sx={{ fontWeight: 'bold' }}
        >
          Profile
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleProfileMenuClose();
            navigate('/');
          }}
          sx={{
            fontSize: '16px',
            fontWeight: 'bold',
            color: "red",
            display: 'flex',
            alignItems: 'center'
          }}
        >
          Logout <LogoutIcon sx={{ ml: 1 }} />
        </MenuItem>
      </Menu>

      <MuiMenu
        anchorEl={notificationAnchorEl}
        open={notificationMenuOpen}
        onClose={handleNotificationClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        {notifications.length > 0 ? (
          notifications.map((notif) => (
            <MenuItem
              key={notif.notification_status_id}
              onClick={() => {
                axios.post(`${baseurl}/notifications/mark-as-read/`, {
                  user_id: parseInt(userId),
                  notification_id: notif.notification_status_id
                })
                  .then(() => {
                    setNotifications(prev => prev.filter(n => n.notification_status_id !== notif.notification_status_id));
                    handleNotificationClose();
                    navigate('/p-assets');
                  })
                  .catch(error => {
                    console.error("Error marking notification as read:", error);
                  });
              }}
            >
              {notif.message}
            </MenuItem>
          ))
        ) : (
          <MenuItem disabled>No notifications</MenuItem>
        )}
      </MuiMenu>
    </>
  );
}
