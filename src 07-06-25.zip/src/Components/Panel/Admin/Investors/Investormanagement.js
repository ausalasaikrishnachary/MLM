import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Button,
  IconButton,
  Container,
  Typography,
  Box
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import Header from "../../../Shared/Navbar/Navbar";
import { baseurl } from '../../../BaseURL/BaseURL';
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material";

const Tmanagement = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRole, setSelectedRole] = useState("All");
const uniqueRoles = ["All", ...new Set(data.map(user => user.role).filter(Boolean))];

const filteredData = selectedRole === "All"
  ? data
  : data.filter(user => user.role === selectedRole);



  useEffect(() => {
    axios
      .get(`${baseurl}/users/`)
      .then((res) => {
        const transformed = res.data.map((user) => ({
          id: user.user_id,
          name: `${user.first_name} ${user.last_name}`,
          email: user.email,
          phone: user.phone_number,
          status: user.status,
          role: user.roles[0]?.role_name || "",
          referralId: user.referral_id,
          kycStatus: user.kyc_status,
          fullData: user,
          created_at: user.created_at
        }));
        setData(transformed);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching data:", err);
        setLoading(false);
      });
  }, []);

  const handleView = (user) => {
    navigate("/View_Tmanagement", { state: { user } });
  };

  const handleEdit = (user) => {
    navigate("/Edit_Tmanagement", { state: { user } });
  };

  const handleDelete = (user_id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      axios
        .delete(`${baseurl}/users/${user_id}`)
        .then((res) => {
          if (res.status === 200) {
            setData((prevData) => prevData.filter((user) => user.id !== user_id));
            console.log("User deleted successfully");
          } else {
            console.error("Failed to delete user");
          }
        })
        .catch((err) => {
          console.error("Error deleting user:", err.response ? err.response.data : err);
          alert("Error deleting user, please try again.");
        });
    }
  };

  const cellStyle = {
    fontWeight: 'bold',
    textAlign: 'center',
    border: '1px solid #000',
    backgroundColor: '#f0f0f0',
  };

  const cellBodyStyle = {
    textAlign: 'center',
    border: '1px solid #000',
  };

  const noDataStyle = {
    textAlign: 'center',
    border: '1px solid #000',
    padding: 2,
  };

  return (
    <>
      <Header />
      <Container>
        <div style={{ textAlign: 'center', marginTop: "12%" }}>
          {/* <h2 style={{ fontWeight: 'bold' }}>Leads Management</h2> */}
        </div>
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
  <FormControl sx={{ minWidth: 200 }}>
    <InputLabel id="role-filter-label">Filter by Role</InputLabel>
    <Select
      labelId="role-filter-label"
      value={selectedRole}
      label="Filter by Role"
      onChange={(e) => setSelectedRole(e.target.value)}
    >
      {uniqueRoles.map((role) => (
        <MenuItem key={role} value={role}>
          {role || "Unknown"}
        </MenuItem>
      ))}
    </Select>
  </FormControl>

  {/* <Button variant="contained" color="primary" onClick={() => navigate("/a-add-lead")}>
    Add Lead
  </Button> */}
</Box>

     


        <Table sx={{ border: '1px solid black', width: '100%' }}>
          <TableHead>
            <TableRow>
              <TableCell sx={cellStyle}>User ID</TableCell>
              <TableCell sx={cellStyle}>Name</TableCell>
              <TableCell sx={cellStyle}>Email</TableCell>
              <TableCell sx={cellStyle}>Phone</TableCell>
              <TableCell sx={cellStyle}>Role</TableCell>
              <TableCell sx={cellStyle}>Referral ID</TableCell>
              <TableCell sx={cellStyle}>Created At</TableCell>
              <TableCell sx={cellStyle}>Actions</TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={8} sx={noDataStyle}>Loading...</TableCell>
              </TableRow>
            ) : data.length > 0 ? (
              filteredData.map((user) => (
                <TableRow key={user.id}>
                  <TableCell sx={cellBodyStyle}>{user.id}</TableCell>
                  <TableCell sx={cellBodyStyle}>{user.name}</TableCell>
                  <TableCell sx={cellBodyStyle}>{user.email}</TableCell>
                  <TableCell sx={cellBodyStyle}>{user.phone}</TableCell>
                  <TableCell sx={cellBodyStyle}>{user.role}</TableCell>
                  <TableCell sx={cellBodyStyle}>{user.referralId}</TableCell>
                  <TableCell sx={cellBodyStyle}>
                    {new Date(user.created_at).toLocaleDateString('en-IN')}
                  </TableCell>
                  <TableCell sx={cellBodyStyle}>
                    <Box sx={{ display: 'flex', justifyContent: 'center', gap: '5px' }}>
                      <IconButton 
                        color="primary" 
                        size="small" 
                        onClick={() => handleView(user.fullData)}
                      >
                        <VisibilityIcon fontSize="small" />
                      </IconButton>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(user.fullData)}
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        size="small" 
                        onClick={() => handleDelete(user.id)}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} sx={noDataStyle}>No Data Found</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Container>
    </>
  );
};

export default Tmanagement;