import React from 'react'

function BuyPlan() {
  return (
    <div>
      
    </div>
  )
}

export default BuyPlan
