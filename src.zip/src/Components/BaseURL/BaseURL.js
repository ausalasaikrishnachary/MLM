// export const baseurl = "https://rahul30.pythonanywhere.com";

// export const baseurl = "http://46.37.122.105:8001";

export const baseurl = "https://shrirajteam.com:81";
