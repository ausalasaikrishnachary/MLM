import React from 'react'

const View_Tmanagement = () => {
  return (
    <div>View_Tmanagement</div>
  )
}

export default View_Tmanagement